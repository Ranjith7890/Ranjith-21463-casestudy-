import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TimeSheetService } from '../timeshet-service';

@Component({
  selector: 'app-create-time-sheet',
  templateUrl: './create-time-sheet.component.html',
  styleUrls: ['./create-time-sheet.component.css']
})
export class CreateTimeSheetComponent implements OnInit {
public timeSheetForm !: FormGroup;
  constructor(private fb: FormBuilder,private timesheet:TimeSheetService,private rs :Router) { }

  ngOnInit(): void {
    this.timeSheetForm = this.fb.group({
    empId : [null,Validators.required],
    date: [null,Validators.required],
    activity : [null,Validators.required],
    description: [null,Validators.required],
    hrs : [null,[Validators.min(0),Validators.max(8), Validators.required]],
    status: [null,Validators.required]
    })
  }
  onSubmit(){
    console.log(this.timeSheetForm.value);
    this.timesheet.insertTimesheet(this.timeSheetForm.value).subscribe(res =>{
      this.rs.navigate(['timesheet']);
      console.log(res);
    } 
      
      )
  }
}

