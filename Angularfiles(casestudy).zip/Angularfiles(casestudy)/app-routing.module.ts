import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { TimeSheetDetailsComponent } from './time-sheet-details/time-sheet-details.component';
import { CreateTimeSheetComponent } from './create-time-sheet/create-time-sheet.component';

const routes: Routes = [{
  path:'',redirectTo:'users',pathMatch:'full'

},{
  path:'timesheet',component:TimeSheetDetailsComponent 
},{
  path:'createtimesheet',component:CreateTimeSheetComponent
},
  {
    
    path:'users',component:LoginComponent
  }
  ,
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
