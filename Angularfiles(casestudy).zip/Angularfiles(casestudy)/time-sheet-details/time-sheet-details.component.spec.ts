import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimeSheetDetailsComponent } from './time-sheet-details.component';

describe('TimeSheetDetailsComponent', () => {
  let component: TimeSheetDetailsComponent;
  let fixture: ComponentFixture<TimeSheetDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TimeSheetDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeSheetDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
