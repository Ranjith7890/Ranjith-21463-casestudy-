import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TimeSheet } from '../timeSheet';
import { TimeSheetService } from '../timeshet-service';
import { UserService } from '../UserService';

@Component({
  selector: 'app-time-sheet-details',
  templateUrl: './time-sheet-details.component.html',
  styleUrls: ['./time-sheet-details.component.css']
})
export class TimeSheetDetailsComponent implements OnInit {
  public timesheet!:TimeSheet[];
  public isManager:boolean = false;
  constructor(private timesheetService:TimeSheetService ,private user: UserService,private rs :Router) { }

  ngOnInit() {
    if(this.user.user.Role == "Manager"){
      this.isManager = true;
      this.timesheetService.getAllTimeSheets(this.user.empId)
    .subscribe(data =>this.timesheet = data)
  }else{
    this.isManager = false;
    this.timesheetService.getTimeSheets(this.user.empId)
    .subscribe(data =>this.timesheet = data)
  }
}
  create(){
    this.rs.navigate(['createtimesheet']);

  }
  approveOrReject(type:string,timeSheet :TimeSheet){
    timeSheet.status = type;
    this.timesheetService.changeStatus(timeSheet).subscribe(res=>{
      console.log(res);


    })
    
  }
}
