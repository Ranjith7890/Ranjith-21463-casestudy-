export class TimeSheet{
    id! : number;
    empId!: number;
    date!: Date;
    activity! : string;
    description!: string;
    hrs! : number;
    status!: string;
}