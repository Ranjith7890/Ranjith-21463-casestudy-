export class  user{
    empid! : number;
    Role!: string;
    username! : string;
    password ! : string;

}