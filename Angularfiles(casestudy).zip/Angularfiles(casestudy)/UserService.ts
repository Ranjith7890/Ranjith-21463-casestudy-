import { Injectable } from "@angular/core";
import { HttpClient} from '@angular/common/http' ;
import { Observable} from 'rxjs';
import { user } from "./user";


@Injectable({
    providedIn:'root'
})
export class UserService{
    private url:string = "http://localhost:8080/login" ;
    public empId!:number ;
    public user! : user;
    constructor(private http:HttpClient){} 
    insertUser(payload:user):Observable<any>{
        return this.http.post(this.url,payload);
    }
}