import { Injectable } from "@angular/core";
import { HttpClient} from '@angular/common/http' ;
import { TimeSheet } from "./timeSheet";
import { Observable} from 'rxjs';


@Injectable({
    providedIn:'root'
})
export class TimeSheetService{
    private url:string = "" ;
    private url1:string = "http://localhost:8080/insert" ;
    private url2:string = "http://localhost:8080/update" ;
    constructor(private http:HttpClient){}
getTimeSheets(empId:number):Observable<TimeSheet[]>{
    this.url = `http://localhost:8080/timesheets/${empId}`
    return this.http.get<TimeSheet[]>(this.url);
}
getAllTimeSheets(empId:number):Observable<TimeSheet[]>{
    this.url = `http://localhost:8080/timesheet`
    return this.http.get<TimeSheet[]>(this.url);
}
insertTimesheet(payload:TimeSheet):Observable<any>{
    return this.http.post(this.url1,payload);
}
changeStatus(payload : any):Observable<any>{
    return this.http.post(this.url2,payload);

}
}