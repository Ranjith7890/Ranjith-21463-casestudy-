import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../UserService';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public UserForm!:FormGroup;
  constructor(private fb: FormBuilder,private userService:UserService,private rs :Router) { }

  ngOnInit(): void {
    this.UserForm = this.fb.group({
      Role : null,
      username : null,
      password : null
    })
  }
  onSubmit(){
     console.log(this.UserForm.value);
    this.userService.insertUser(this.UserForm.value).subscribe(res =>{
    this.userService.empId=res.user.empid;
      this.userService.user=res.user;
     this.rs.navigate(['timesheet']);
      console.log(res);
    } 
      
      )
  }

}

