package com.sonata.model;

import java.sql.Date;

public class TimeSheet {
	 int id;
	 int empId;
	  Date date;
	 String activity;
	 String description;
	 int hrs;
	 String status;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getHrs() {
		return hrs;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "TimeSheet [id=" + id + ", empId=" + empId + ", date=" + date + ", activity=" + activity
				+ ", description=" + description + ", hrs=" + hrs + ", status=" + status + "]";
	}
	
}
