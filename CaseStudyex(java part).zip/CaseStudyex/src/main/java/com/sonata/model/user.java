package com.sonata.model;

public class user {
	 public int empid;
	  public String Role;
	  public String username;
	  public String password;
	  
}
