package com.sonata.Interface;

import java.sql.SQLException;
import java.util.List;

import com.sonata.model.Employee;
import com.sonata.model.TimeSheet;
import com.sonata.model.SuccessMessage;
import com.sonata.model.UserTable;
import com.sonata.model.user;

public interface CaseStudyInterface {
	public List<Employee> getAllEmployee();
	public List<TimeSheet> getAllTimeSheet();
	public List<UserTable> getAlluser();
	public SuccessMessage getUser(user obj);
	public SuccessMessage insertTimeSheet(TimeSheet obj);
	public List<TimeSheet> getTimeSheetById(int empId) throws SQLException;
	public SuccessMessage updateTimeSheet(TimeSheet obj);
	
}
