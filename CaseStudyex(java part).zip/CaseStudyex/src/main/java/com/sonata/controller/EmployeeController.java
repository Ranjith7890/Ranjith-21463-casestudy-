package com.sonata.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sonata.Impl.CaseStudyImpl;
import com.sonata.model.Employee;
import com.sonata.model.TimeSheet;
import com.sonata.model.SuccessMessage;
import com.sonata.model.UserTable;
import com.sonata.model.user;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class EmployeeController {
	
	@Autowired
	private CaseStudyImpl Service;
	
	@GetMapping(value="/emp")
	public List<Employee> getEmp(){
		return Service.getAllEmployee();
	}
	@GetMapping(value="/timesheet")
	public List<TimeSheet> geTime(){
		return Service.getAllTimeSheet();
	}
	@GetMapping(value="/user")
	public List<UserTable> getuser(){
		return Service.getAlluser();
	}
	@RequestMapping(method=RequestMethod.POST, value="/login")
	public SuccessMessage getUser(@RequestBody user userdata) {
		return Service.getUser(userdata);
		}
	@GetMapping( value = "/timesheets/{id}")
	public List<TimeSheet> geTimesheets(@PathVariable("id") int id) throws SQLException{
		return Service. getTimeSheetById(id);
	}
	@RequestMapping(method=RequestMethod.POST, value="/insert")
	public SuccessMessage insertTimeSheet(@RequestBody TimeSheet timeSheet) {
		return Service.insertTimeSheet(timeSheet);
		}
	@RequestMapping(method=RequestMethod.POST, value="/update")
	public SuccessMessage updateTimeSheet(@RequestBody TimeSheet timeSheet) {
		return  Service.updateTimeSheet(timeSheet);
		}
}
