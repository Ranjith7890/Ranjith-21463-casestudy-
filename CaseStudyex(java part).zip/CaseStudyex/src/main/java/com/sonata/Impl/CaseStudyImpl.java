package com.sonata.Impl;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sonata.Dbcoonection.DbConnection;
import com.sonata.Interface.CaseStudyInterface;
import com.sonata.model.Employee;
import com.sonata.model.SuccessMessage;
import com.sonata.model.TimeSheet;
import com.sonata.model.UserTable;
import com.sonata.model.user;

@Service
public class CaseStudyImpl implements CaseStudyInterface {
	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> emp = new ArrayList<>();
		try {
			DbConnection db = new DbConnection();
			PreparedStatement ps = db.getConnection().prepareStatement("select * from employee");
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				int empId=rs.getInt(1);
				String empName=rs.getString(2);
				String hcc=rs.getString(3);
				String emailId=rs.getString(4);
				Date doj= rs.getDate(5);

				Employee e1 = new Employee();
				e1.setEmpId(empId);
				e1.setEmpName(empName);
				e1.setHcc(hcc);
				e1.setEmailId(emailId);
				e1.setDoj(doj);
				
				emp.add(e1);
			}
			}catch(SQLException e) {e.printStackTrace();}
		return emp;
	}
	@Override
	public List<TimeSheet> getAllTimeSheet() {
		List<TimeSheet> time = new ArrayList<>();
		try {
			DbConnection db = new DbConnection();
			PreparedStatement ps = db.getConnection().prepareStatement("select * from  timesheet");
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				int id=rs.getInt(1);
				int empId=rs.getInt(2);
				Date date=rs.getDate(3);
				String activity=rs.getString(4);
				String description = rs.getString(5);
				int hrs =rs.getInt(6);
				String status =rs. getString(7);

				TimeSheet s1 = new TimeSheet();
				s1.setId(id);
				s1.setEmpId(empId);
				s1.setDate(date);
				s1.setActivity(activity);
				s1.setDescription(description);
				s1.setHrs(hrs);
				s1.setStatus(status);
				
				time.add(s1);
			}
			}catch(SQLException e) {
				e.printStackTrace();
				}
		return time;
	
}
	@Override
	public List<UserTable> getAlluser() {
		List<UserTable> user = new ArrayList<>();
		try {
			DbConnection db = new DbConnection();
			PreparedStatement ps = db.getConnection().prepareStatement("select * from userstable");
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
			 UserTable u1 = new UserTable();
				String Role=rs.getString(1);
				String username = rs.getString(2);
				String password =rs.getString(3);
				u1.setRole(Role);
				u1.setUsername(username);
				u1.setPassword(password);
				user.add(u1);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			}
		return user;
	}
	@Override
	public SuccessMessage getUser(user obj) {
		String successMessage = " Login Successfully";
		String errorMessage = "No user Found";
		SuccessMessage message= new SuccessMessage();
		
		try {
			DbConnection db = new DbConnection();
			PreparedStatement ps = db.getConnection().prepareStatement("select * from userstable where  Role = ? && username = ? && password = ? ");
			ps.setString(1, obj.Role);
			ps.setString(2, obj.username);
			ps.setString(3, obj.password);
			ResultSet rs= ps.executeQuery();
			   user u1 = new user();
			
			if(rs.next()) {
				u1.empid =rs.getInt(1);
				u1.Role= rs.getString(2);
				u1.username= rs.getString(3);
				u1.password= rs.getString(4);
				message.user=u1;
				
				message.setMessage(successMessage);
				
			}
			else {
				message.setMessage(errorMessage);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			}
		return message;
	}
	@Override
	public SuccessMessage insertTimeSheet(TimeSheet obj) {
		String successMessage = " Inserted Successfully";
		String errorMessage = "Something is Wrong";
		SuccessMessage message= new SuccessMessage();
		
		try {
			DbConnection db = new DbConnection();
			PreparedStatement ps = db.getConnection().prepareStatement("insert into timesheet  (empId,date,activity,description,hrs,status) values ( ?,?,?,?,?,?)");
			ps.setInt(1, obj.getEmpId());
			ps.setDate(2, (java.sql.Date)obj.getDate());
			ps.setString(3, obj.getActivity());
			ps.setString(4, obj.getDescription());
			ps.setInt(5,obj.getHrs());
			ps.setString(6, obj.getStatus());
			 int rows = ps.executeUpdate();
			
			if( rows>0) {
				message.setMessage(successMessage);
				
			}
			else {
				message.setMessage(errorMessage);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			}
		return message;
	}
	@Override
	public List<TimeSheet> getTimeSheetById(int empId) throws SQLException {
		List<TimeSheet> time = new ArrayList<>();
		try {
			DbConnection db = new DbConnection();
			PreparedStatement ps = db.getConnection().prepareStatement("select * from  timesheet where empid = ?");
			ps.setInt(1, empId);
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				int id=rs.getInt(1);
				int empid=rs.getInt(2);
				Date date=rs.getDate(3);
				String activity=rs.getString(4);
				String description = rs.getString(5);
				int hrs =rs.getInt(6);
				String status =rs. getString(7);

				TimeSheet s1 = new TimeSheet();
				s1.setId(id);
				s1.setEmpId(empid);
				s1.setDate(date);
				s1.setActivity(activity);
				s1.setDescription(description);
				s1.setHrs(hrs);
				s1.setStatus(status);
				
				time.add(s1);
			}
			}catch(SQLException e) {
				e.printStackTrace();
				}
		return time;
	}
	@Override
	public SuccessMessage updateTimeSheet(TimeSheet obj) {
		String successMessage = " Updated Successfully";
		String errorMessage = "Somrthing is Wrong";
		SuccessMessage message= new SuccessMessage();
		
		try {
			DbConnection db = new DbConnection();
			PreparedStatement ps = db.getConnection().prepareStatement("update timesheet set status = ? where id = ?");
			ps.setString(1, obj.getStatus());
			ps.setInt(2, obj.getId());
			 int rows = ps.executeUpdate();
			
			if( rows>0) {
				message.setMessage(successMessage);
				
			}
			else {
				message.setMessage(errorMessage);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			}
		return message;
	}
}
